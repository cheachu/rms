import csv

def check_column_sum(name,csv_file, output_file, start_column=None, end_column=None, *column_indices):
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        data = list(reader)
        last_row = data[-1]

        if start_column is None and end_column is None:  # If only one column index is provided
            column_index = column_indices[0]
            column_sum = float(last_row[column_index - 1])
            error_status = "OK" if column_sum <= 0 else "SLAVE DEVICE FAULT"
            with open(output_file, 'a', newline='') as output_csv:  # Append mode
                writer = csv.writer(output_csv)
                if file.tell() == 0:  # If the file is empty, write headers
                    writer.writerow(["Heading", "Error"])
                writer.writerow(["Column " + str(column_index), error_status])
            return column_sum
        else:  # If a range of columns is provided
            total_sum = 0
            for index in range(start_column, end_column + 1):
                total_sum += float(last_row[index - 1])
            error_status = "OK" if total_sum <= 0 else "SLAVE DEVICE FAULT"
            with open(output_file, 'a', newline='') as output_csv:  # Append mode
                writer = csv.writer(output_csv)
                if file.tell() == 0:  # If the file is empty, write headers
                    writer.writerow(["Heading", "Error"])
                writer.writerow([name, error_status])
            return total_sum

