import os
import pandas as pd
import tkinter as tk
from tkinter import filedialog

def select_input_folder():
    folder_path = filedialog.askdirectory()
    input_folder_entry.delete(0, tk.END)
    input_folder_entry.insert(0, folder_path)

def select_output_folder():
    folder_path = filedialog.askdirectory()
    output_folder_entry.delete(0, tk.END)
    output_folder_entry.insert(0, folder_path)

def combine_and_sort():
    input_folder = input_folder_entry.get()
    output_folder = output_folder_entry.get()

    if not input_folder or not output_folder:
        status_label.config(text="Please select input and output folders.")
        return

    csv_files = [f for f in os.listdir(input_folder) if f.endswith('.csv')]
    if not csv_files:
        status_label.config(text="No CSV files found in the selected folder.")
        return

    dfs = []
    for csv_file in csv_files:
        file_path = os.path.join(input_folder, csv_file)
        df = pd.read_csv(file_path)
        dfs.append(df)

    combined_df = pd.concat(dfs, ignore_index=True)
    sorted_df = combined_df.sort_values(by='SiteID')  # Sort by 'SiteID' column

    output_path = os.path.join(output_folder, 'march.csv')
    sorted_df.to_csv(output_path, index=False)

    status_label.config(text=f"Combined and sorted CSV file saved as 'march.csv' in {output_folder}")

# Create GUI window
window = tk.Tk()
window.title("CSV File Combiner and Sorter")

# Input folder selection
input_folder_label = tk.Label(window, text="Select Input Folder:")
input_folder_label.grid(row=0, column=0, padx=5, pady=5)

input_folder_entry = tk.Entry(window, width=50)
input_folder_entry.grid(row=0, column=1, padx=5, pady=5)

input_folder_button = tk.Button(window, text="Browse", command=select_input_folder)
input_folder_button.grid(row=0, column=2, padx=5, pady=5)

# Output folder selection
output_folder_label = tk.Label(window, text="Select Output Folder:")
output_folder_label.grid(row=1, column=0, padx=5, pady=5)

output_folder_entry = tk.Entry(window, width=50)
output_folder_entry.grid(row=1, column=1, padx=5, pady=5)

output_folder_button = tk.Button(window, text="Browse", command=select_output_folder)
output_folder_button.grid(row=1, column=2, padx=5, pady=5)

# Combine and sort button
combine_button = tk.Button(window, text="Combine and Sort", command=combine_and_sort)
combine_button.grid(row=2, column=1, padx=5, pady=10)

# Status label
status_label = tk.Label(window, text="")
status_label.grid(row=3, column=1, padx=5, pady=5)

window.mainloop()
