import os
import tkinter as tk
from tkinter import filedialog
import pandas as pd

def select_folder():
    folderpath = filedialog.askdirectory()
    if folderpath:
        entry_folder_path.delete(0, tk.END)
        entry_folder_path.insert(0, folderpath)

def filter_and_save_files():
    folderpath = entry_folder_path.get()
    if folderpath:
        files = [f for f in os.listdir(folderpath) if f.endswith('.csv')]
        for file in files:
            filepath = os.path.join(folderpath, file)
            df = pd.read_csv(filepath)
            filtered_df = df[df['SiteID'].str.startswith('TD')]
            sorted_df = filtered_df.sort_values(by='SiteID')
            save_filepath = os.path.join(folderpath, f"filtered_sorted_{file}")
            sorted_df.to_csv(save_filepath, index=False)
            os.remove(filepath)  # Delete the original file
        tk.messagebox.showinfo("Success", "Filtered and sorted files saved and original files deleted successfully!")

# Create the main window
root = tk.Tk()
root.title("Folder CSV Filter, Sort, and Delete Originals")

# Folder selection frame
frame_folder = tk.Frame(root)
frame_folder.pack(pady=10)

label_folder = tk.Label(frame_folder, text="Select folder containing CSV files:")
label_folder.grid(row=0, column=0)

entry_folder_path = tk.Entry(frame_folder, width=50)
entry_folder_path.grid(row=0, column=1)

button_browse_folder = tk.Button(frame_folder, text="Browse", command=select_folder)
button_browse_folder.grid(row=0, column=2)

# Filter, save, and delete button
button_filter_save_delete = tk.Button(root, text="Filter, Save, and Delete Originals", command=filter_and_save_files)
button_filter_save_delete.pack(pady=10)

# Run the application
root.mainloop()
