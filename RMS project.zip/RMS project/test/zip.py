# importing the zipfile module 
from zipfile import ZipFile 
  
# loading the temp.zip and creating a zip object 
with ZipFile("C:/Users/cheac/Desktop/Feb 2024 - Copy/sonic-logs 21 to 25 Feb 2024.zip", 'r') as zObject: 
  
    # Extracting all the members of the zip  
    # into a specific location. 
    zObject.extractall( 
        path="C:/Users/cheac/Desktop/speed") 