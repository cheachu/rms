import pandas as pd
import os

def split_excel(input_file):
    # Create a directory to store the new Excel files
    output_directory = "split_excel_files"
    os.makedirs(output_directory, exist_ok=True)

    # Read the Excel file
    df = pd.read_excel(input_file)

    # Split and save each row as a new Excel file
    for i, row in df.iterrows():
        # Extract SiteID value
        site_id = row['Site ID']

        # Create a new Excel file for each row with filename based on SiteID
        output_file = os.path.join(output_directory, f"{site_id}.xlsx")
        row_df = pd.DataFrame([row])
        row_df.to_excel(output_file, index=False)

        print(f"Created Excel file for row {i+1} with SiteID {site_id}: {output_file}")

if __name__ == "__main__":
    input_file = "input.xlsx"  # Change this to your input Excel file
    split_excel(input_file)
