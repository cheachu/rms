import os
import csv
import tkinter as tk
from tkinter import filedialog, messagebox

def convert_log_to_csv(log_file, csv_file, delimiter=','):
    with open(log_file, 'r') as log_file:
        log_data = [line.strip().split(delimiter) for line in log_file]

    with open(csv_file, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerows(log_data)

def convert_and_remove(log_folder):
    for filename in os.listdir(log_folder):
        if filename.endswith(".log"):
            log_file_path = os.path.join(log_folder, filename)
            csv_file_path = os.path.join(log_folder, filename.replace(".log", ".csv"))
            convert_log_to_csv(log_file_path, csv_file_path)
            os.remove(log_file_path)

    messagebox.showinfo("Conversion Complete", "Log files converted to CSV and old log files removed.")

def browse_folder():
    folder_path = filedialog.askdirectory()
    if folder_path:
        convert_and_remove(folder_path)

# Create the main window
root = tk.Tk()
root.title("Log to CSV Converter")

# Create and place a browse button
browse_button = tk.Button(root, text="Browse", command=browse_folder)
browse_button.pack(pady=20)

# Run the Tkinter event loop
root.mainloop()
