import os
import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox

def sort_csv_folder():
    # Open folder dialog to select a folder
    folder_path = filedialog.askdirectory()
    if not folder_path:
        return

    try:
        # List all files in the selected folder
        files = os.listdir(folder_path)
        
        # Filter out CSV files
        csv_files = [f for f in files if f.endswith('.csv')]

        if not csv_files:
            messagebox.showinfo("Info", "No CSV files found in the selected folder.")
            return

        for csv_file in csv_files:
            file_path = os.path.join(folder_path, csv_file)

            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)

            # Sort DataFrame by the first column
            df_sorted = df.sort_values(by=df.columns[0])

            # Save the sorted DataFrame to a new CSV file
            save_path = os.path.join(folder_path, f"{os.path.splitext(csv_file)[0]}.csv")
            df_sorted.to_csv(save_path, index=False)
            
            # Remove the original unsorted CSV file
            os.remove(file_path)

        messagebox.showinfo("Success", "All CSV files sorted and unsorted files removed.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

# Create the GUI
root = tk.Tk()
root.title("CSV Sorter - Folder")

# Create a button to trigger sorting
sort_button = tk.Button(root, text="Sort CSVs in Folder", command=sort_csv_folder)
sort_button.pack(pady=20)

root.mainloop()
