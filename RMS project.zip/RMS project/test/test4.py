import tkinter as tk
from tkinter import filedialog
import pandas as pd
import os

def select_file():
    file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    entry_file_path.delete(0, tk.END)
    entry_file_path.insert(0, file_path)

def select_directory():
    dir_path = filedialog.askdirectory()
    entry_output_dir.delete(0, tk.END)
    entry_output_dir.insert(0, dir_path)

def split_csv():
    input_csv = entry_file_path.get()
    output_dir = entry_output_dir.get()

    if not input_csv or not output_dir:
        tk.messagebox.showerror("Error", "Please select input CSV file and output directory.")
        return
    
    df = pd.read_csv(input_csv)
    unique_siteids = df['SiteID'].unique()

    for siteid in unique_siteids:
        site_df = df[df['SiteID'] == siteid]
        filename = os.path.join(output_dir, f"{siteid}.csv")
        site_df.to_csv(filename, index=False)
        print(f"Created {filename}")
    
    tk.messagebox.showinfo("Success", "CSV files split successfully.")

# Create main window
root = tk.Tk()
root.title("CSV Splitter")

# Input CSV file selection
label_file_path = tk.Label(root, text="Input CSV File:")
label_file_path.grid(row=0, column=0, padx=5, pady=5)
entry_file_path = tk.Entry(root, width=50)
entry_file_path.grid(row=0, column=1, padx=5, pady=5)
button_browse_file = tk.Button(root, text="Browse", command=select_file)
button_browse_file.grid(row=0, column=2, padx=5, pady=5)

# Output directory selection
label_output_dir = tk.Label(root, text="Output Directory:")
label_output_dir.grid(row=1, column=0, padx=5, pady=5)
entry_output_dir = tk.Entry(root, width=50)
entry_output_dir.grid(row=1, column=1, padx=5, pady=5)
button_browse_dir = tk.Button(root, text="Browse", command=select_directory)
button_browse_dir.grid(row=1, column=2, padx=5, pady=5)

# Split button
button_split = tk.Button(root, text="Split CSV", command=split_csv)
button_split.grid(row=2, column=1, padx=5, pady=5)

# Run the application
root.mainloop()
