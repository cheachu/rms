import os

folder_path = "C:/Users/cheac/Desktop/far"

# Get all files in the folder
files = os.listdir(folder_path)

# Iterate through each file
for file in files:
    if file.endswith(".csv") or file.endswith(".xlsx"):
        # Check if there's a file with the same name but different extension
        base_name, extension = os.path.splitext(file)
        opposite_extension = ".csv" if extension == ".xlsx" else ".xlsx"
        opposite_file = base_name + opposite_extension
        if opposite_file in files:
            # If such a file exists, remove both files
            os.remove(os.path.join(folder_path, file))
            os.remove(os.path.join(folder_path, opposite_file))
            print(f"Removed {file} and {opposite_file}")
