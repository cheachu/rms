import os

def add_csv_extension(folder_path):
    # List all files in the folder
    files = os.listdir(folder_path)
    
    # Iterate through each file
    for file in files:
        # Check if the item is a file
        if os.path.isfile(os.path.join(folder_path, file)):
            # Split the filename and extension
            filename, extension = os.path.splitext(file)
            # If the file doesn't already have a .csv extension, add it
            if extension != '.csv':
                new_filename = filename + '.csv'
                # Rename the file with the new extension
                os.rename(os.path.join(folder_path, file), os.path.join(folder_path, new_filename))
                print(f"Renamed '{file}' to '{new_filename}'")

# Replace 'folder_path' with the path to your folder
folder_path = "C:/Users/cheac/Desktop/march_final"
add_csv_extension(folder_path)
