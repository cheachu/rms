import csv
import pandas as pd

def subtract_and_update(file1, file2, cell1, cell2, output_file):
    # Read data from CSV and Excel files
    data_csv = pd.read_csv(file1)
    data_excel = pd.read_excel(file2)
    
    # Subtract values from specified cells
    value1 = data_csv.iloc[cell1[0], cell1[1]]
    value2 = data_excel.iloc[cell2[0], cell2[1]]
    
    # Update output.csv
    with open(output_file, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([value1, value2])

# Example usage:
file1 = 'data.csv'
file2 = 'data1.xlsx'
cell1 = (1, 2)  # Row, Column for data.csv
cell2 = (3, 1)  # Row, Column for data1.xlsx
output_file = 'output.csv'

subtract_and_update(file1, file2, cell1, cell2, output_file)
