import tkinter as tk
from tkinter import filedialog
import pandas as pd

def merge_files():
    # Read the first output.csv file
    df2 = pd.read_csv('output1.csv')

    # Read the second output.csv file
    df3 = pd.read_csv('output3.csv')

    # Read the third output.csv file
    df1 = pd.read_csv('output.csv')

    # Check for overlapping data and resolve conflicts (if any)
    # Assuming there are no overlapping data for simplicity

    # Concatenate the data from all files
    merged_df = pd.concat([df1, df2, df3], ignore_index=True)

    # Open a file dialog to select the filename for the merged output file
    filename = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx")])

    # Write the concatenated data to the selected filename
    if filename:
        merged_df.to_excel(filename, index=False)
        print("Merging completed. Merged data saved to", filename)
        root.destroy()  # Close the GUI window after saving the file

# Create a GUI window
root = tk.Tk()
root.title("Merge Output Files")

# Set the window size
root.geometry("300x100")

# Create a button to trigger merging files
merge_button = tk.Button(root, text="Merge Files", command=merge_files)
merge_button.pack(pady=20)

root.mainloop()
