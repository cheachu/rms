import csv
import openpyxl

def get_column_name_csv(csv_file, col_index):
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        headers = next(reader)  # Read the header row
        return headers[col_index - 1] if col_index <= len(headers) else None

def get_column_name_excel(excel_file, sheet_name, col_index):
    wb = openpyxl.load_workbook(excel_file)
    sheet = wb[sheet_name]
    return sheet.cell(row=1, column=col_index).value

def compare_cells_csv(csv_file, row1, col1, row2, col2):
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip the header row
        data = list(reader)
        value1 = float(data[row1 - 1][col1 - 1])
        value2 = float(data[row2 - 1][col2 - 1])
        return value1 - value2

def compare_cells_excel(excel_file, sheet_name, row1, col1, row2, col2):
    wb = openpyxl.load_workbook(excel_file)
    sheet = wb[sheet_name]
    value1 = float(sheet.cell(row=row1, column=col1).value)
    value2 = float(sheet.cell(row=row2, column=col2).value)
    return value1 - value2

def write_to_output_csv(result):
    with open('output.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(result)

# Example usage
csv_file = 'output.csv'
excel_file = 'data1.xlsx'
sheet_name = 'Sheet1'

# Get column names from CSV and Excel files
csv_col_index = 1
excel_col_index = 1
csv_column_name1 = get_column_name_csv(csv_file, csv_col_index)
csv_column_name2 = get_column_name_csv(csv_file, csv_col_index + 1)
excel_column_name1 = get_column_name_excel(excel_file, sheet_name, excel_col_index)
excel_column_name2 = get_column_name_excel(excel_file, sheet_name, excel_col_index + 1)

# Values from Excel file
excel_row1 = 2
excel_col1 = 1
excel_row2 = 3
excel_col2 = 1
wb = openpyxl.load_workbook(excel_file)
sheet = wb[sheet_name]
excel_value1 = sheet.cell(row=excel_row1, column=excel_col1).value
excel_value2 = sheet.cell(row=excel_row2, column=excel_col2).value

# Values from CSV file
csv_row1 = 2
csv_col1 = 1
csv_row2 = 3
csv_col2 = 2
with open(csv_file, 'r') as file:
    reader = csv.reader(file)
    next(reader)  # Skip the header row
    data = list(reader)
    csv_value1 = data[csv_row1 - 1][csv_col1 - 1]
    csv_value2 = data[csv_row2 - 1][csv_col2 - 1]

# Compare values
comparison_result1 = compare_cells_csv(csv_file, csv_row1, csv_col1, csv_row2, csv_col2)
comparison_result2 = compare_cells_excel(excel_file, sheet_name, excel_row1, excel_col1, excel_row2, excel_col2)
write_to_output_csv([excel_column_name1, excel_value1, csv_column_name1, csv_value1, excel_column_name2, excel_value2, csv_column_name2, csv_value2, comparison_result1, comparison_result2])
