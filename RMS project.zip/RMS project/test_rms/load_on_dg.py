#program to calculate Load on dg and the current 
import numpy as np 
import pandas as pd 
import csv

input_file='data.csv'
with open(input_file,'r') as file:
    reader=csv.reader(file)
    data=list(reader)
    