import csv

def get_cell_value(file_path, row, column):
    with open(file_path, 'r', encoding='utf-8') as file:  # Specify encoding
        reader = csv.reader(file)
        data = list(reader)
        try:
            value = data[row][column]
            return float(value) if '.' in value else int(value)  # Convert to float if it's a decimal
        except IndexError:
            return None


def main(excel_row,excel_column,csv_row,csv_column):
    excel_file = 'data1.xlsx'
    csv_file = 'output.csv'
    output_file = "output.csv"

    # excel_row = int(input("Enter row number in Excel file: "))
    # excel_column = int(input("Enter column number in Excel file: "))
    # csv_row = int(input("Enter row number in CSV file: "))
    # csv_column = int(input("Enter column number in CSV file: "))

    excel_value = get_cell_value(excel_file, excel_row, excel_column)
    csv_value = get_cell_value(csv_file, csv_row, csv_column)

    if excel_value is not None and csv_value is not None:
        difference = excel_value - csv_value
        with open(output_file, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([difference])
        print(f"Difference: {difference} saved to {output_file}")
    else:
        print("Invalid row or column numbers. Please check and try again.")

if __name__ == "__main__":
    main(2,12,8,4)
