import pandas as pd

# Read CSV files
file1 = pd.read_csv('output.csv')
file2 = pd.read_csv('output1.csv')
file3 = pd.read_csv('output3.csv')

# Remove blank spaces in each DataFrame
file1_cleaned = file1.dropna(axis=0, how='all')
file2_cleaned = file2.dropna(axis=0, how='all')
file3_cleaned = file3.dropna(axis=0, how='all')

# Concatenate DataFrames vertically
combined_data = pd.concat([file1_cleaned, file2_cleaned, file3_cleaned], ignore_index=True)

# Replace null values with empty string
combined_data = combined_data.fillna('')

# Write to Excel
combined_data.to_excel('combined_data_without_blanks.xlsx', index=False)
