import csv

def check_column_sum(csv_file, start_column=None, end_column=None, *column_indices):
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        data = list(reader)
        last_row = data[-1]

        if start_column is None and end_column is None:  # If only one column index is provided
            column_index = column_indices[0]
            column_sum = float(last_row[column_index - 1])
            print(f"Sum of column {column_index} in the last row is {column_sum}")
            
            if column_sum > 0:
                print("Sensor Error: Sum is greater than 0!")
            else:
                print("Sum is within normal range.")
            
            return column_sum
        else:  # If a range of columns is provided
            total_sum = 0
            for index in range(start_column, end_column + 1):
                total_sum += float(last_row[index - 1])
            
            print(f"Sum of columns from {start_column} to {end_column} in the last row is {total_sum}")
            
            if total_sum > 0:
                print("Sensor Error: Sum is greater than 0!")
            else:
                print("Sum is within normal range.")
            
            return total_sum

# Example usage:
csv_file = 'data.csv'
start_column = 361  
end_column =361 
column_indices = (15, 16, 17)  

check_column_sum(csv_file, start_column, end_column, *column_indices)
