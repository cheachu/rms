import pandas as pd

def compare_values(excel_file, csv_file, excel_column_num, csv_column_num):
    # Read Excel file
    excel_data = pd.read_excel(excel_file)
    
    # Read CSV file
    csv_data = pd.read_csv(csv_file)
    
    # Merge dataframes on common column
    merged_data = pd.merge(excel_data, csv_data, how='inner', left_on=excel_data.columns[excel_column_num], right_on=csv_data.columns[csv_column_num])
    
    # Calculate difference
    merged_data['Difference'] = merged_data.iloc[:, excel_column_num] - merged_data.iloc[:, csv_column_num]
    
    return merged_data

# Example usage
excel_file = 'data1.xlsx'
csv_file = 'output.csv'
excel_column_num = 10  # Change to the column number in the Excel file
csv_column_num = 4  # Change to the column number in the CSV file

result = compare_values(excel_file, csv_file, excel_column_num, csv_column_num)
print(result)
