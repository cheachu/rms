import pandas as pd

def compare_columns_and_write_result(csv_file, column_number, columns_to_compare):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file)
    
    # Check if the column numbers are valid
    if column_number >= len(df.columns) or any(col >= len(df.columns) for col in columns_to_compare):
        return "Invalid column number"
    
    # Create an empty DataFrame to store the result
    result_df = pd.DataFrame(columns=df.columns)
    
    # Iterate through each row and perform the comparison
    for i in range(1, len(df)):
        if df.iloc[i, column_number] == 1:
            row = df.iloc[i, :]
            for col in columns_to_compare:
                row[col] -= df.iloc[i-1, col]
            result_df = result_df.append(row, ignore_index=True)
    
    # Write the result to a new CSV file
    result_file = "result.csv"
    result_df.to_csv(result_file, index=False)
    
    return f"Result written to {result_file}"

# Example usage:
csv_file = "data.csv"
column_number = 46  # Column number to compare
columns_to_compare = [44]  # List of column numbers to compare with

result_message = compare_columns_and_write_result(csv_file, column_number, columns_to_compare)
print(result_message)
