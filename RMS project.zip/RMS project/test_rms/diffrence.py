import pandas as pd

def subtract_values(csv_file, excel_file, csv_row, csv_col, excel_row, excel_col, output_file):
    try:
        # Read CSV file
        csv_data = pd.read_csv(csv_file)
        # Read Excel file
        excel_data = pd.read_excel(excel_file)
        # Check if specified row and column indices are within bounds
        if csv_row <= 0 or csv_col <= 0 or excel_row <= 0 or excel_col <= 0:
            raise ValueError("Row and column indices must be positive integers.")
        if csv_row > csv_data.shape[0] or csv_col > csv_data.shape[1]:
            raise ValueError("CSV row or column index out of bounds.")
        if excel_row > excel_data.shape[0] or excel_col > excel_data.shape[1]:
            raise ValueError(f"Excel row or column index out of bounds. Maximum row: {excel_data.shape[0]}, Maximum column: {excel_data.shape[1]}")
        if excel_row < 1 or excel_col < 1:
            raise ValueError("Excel row and column indices must be positive integers.")
        # Get values from CSV and Excel
        csv_value = csv_data.iloc[csv_row - 1, csv_col - 1]
        excel_value = excel_data.iloc[excel_row - 1, excel_col - 1]
        # Get column name from Excel
        excel_col_name = excel_data.columns[excel_col - 1]
        # Check if output file exists
        try:
            existing_data = pd.read_csv(output_file)
            column_names = existing_data.columns.tolist()
        except FileNotFoundError:
            existing_data = None
            column_names = []
        # If output file doesn't exist or column name is not in it, write both column name and difference
        if not existing_data or excel_col_name not in column_names:
            diff_df = pd.DataFrame({excel_col_name: [excel_value], "Difference": [excel_value - csv_value]})
            diff_df.to_csv(output_file, index=False)
            print(f"Column name '{excel_col_name}' and difference ({excel_value} - {csv_value}) written to {output_file}")
        else:
            # If column name exists, append only the difference to the corresponding column
            diff_df = pd.DataFrame({"Difference": [excel_value - csv_value]})
            diff_df.to_csv(output_file, mode='a', header=False, index=False)
            print(f"Difference ({excel_value} - {csv_value}) appended to existing column '{excel_col_name}' in {output_file}")
    except Exception as e:
        print(f"Error: {e}")

