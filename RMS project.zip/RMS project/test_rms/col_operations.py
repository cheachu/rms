import csv

# Function to find the first empty cell in the output file
def find_empty_cell(output_file):
    try:
        with open(output_file, 'r') as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames
            num_rows = sum(1 for _ in file)  # Count the number of rows excluding header
            num_columns = len(headers)
            for row in range(1, num_rows + 2):  # Adjusted to include header
                for col in range(2, num_columns, 2):  # Start checking from the third column
                    if row == 1 or (row > 1 and headers[col] == ""):
                        return row, col  # Return the coordinates of the first empty cell
            return num_rows + 1, 2  # If no empty cell found, return the next available cell
    except FileNotFoundError:
        return 1, 3  # If file doesn't exist, start from the first row, third column
    except Exception as e:
        print("Error:", e)
        return None, None

# Function to subtract the first and last elements of a column and write the result to the output file
# def subtract_first_last(csv_file, column_number, output_file):
#     try:
#         empty_row, empty_col = find_empty_cell(output_file)
#         if empty_row is None or empty_col is None:
#             return "Error finding empty cell"
        
#         with open(csv_file, 'r') as file:
#             reader = csv.DictReader(file)
#             headers = reader.fieldnames
#             header = headers[column_number - 1]  # Extract header from the specified column
#             data = list(reader)
#             column_values = [float(row[header]) for row in data]  # Extract values from the specified column
#             result = column_values[-1] - column_values[0]
                                                                
#         with open(output_file, 'a', newline='') as csvfile:
#             writer = csv.writer(csvfile)
#             if empty_row == 1 or empty_col == 3:  # If the file is empty, write headers
#                 writer.writerow(["Column Name", "Value"])
#             if empty_col == 3:  # If it's the first column of a new row, write the column name
#                 writer.writerow(["", "", header, result])  # Start from column 3
#             else:
#                 writer.writerow(["", "", "", result])  # Append new data in the next available cell
#     except FileNotFoundError:
#         return "File not found"
#     except IndexError:
#         return "Column number out of range"
#     except ValueError:
#         return "Column values are not numeric"
    
# Function to subtract the first and last elements of a column and write the result to the output file
def subtract_first_last(csv_file, column_number, output_file):
    try:
        empty_row, empty_col = find_empty_cell(output_file)
        if empty_row is None or empty_col is None:
            return "Error finding empty cell"
        
        with open(csv_file, 'r') as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames
            header = headers[column_number - 1]  # Extract header from the specified column
            data = list(reader)
            column_values = [float(row[header]) for row in data]  # Extract values from the specified column
            result = column_values[-1] - column_values[0]
                                                                
        with open(output_file, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            if empty_row == 1 or empty_col == 3:  # If the file is empty or starting a new row, write headers
                writer.writerow(["", "Column Name", "Value"])  # Adjusted to start from column 3
            if empty_col == 3:  # If it's the first column of a new row, write the column name
                writer.writerow(["", "", header, result])  # Start from column 3
            else:
                writer.writerow(["", "", "", result])  # Append new data in the next available cell
    except FileNotFoundError:
        return "File not found"
    except IndexError:
        return "Column number out of range"
    except ValueError:
        return "Column values are not numeric"

