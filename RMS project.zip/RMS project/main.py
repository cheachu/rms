import rms_sensors_check
import gui
import col_operations
 

#program to open 2 files
gui.root.mainloop()




#Check each sensors are active or not 


#check for acem fault
print("checking for ACEM sensor Fault")
rms_sensors_check.check_column_sum("ACEM Sensor","data.csv","output.csv",30,30)

#check for dcem fault
print("checking for DCEM sensor Fault")
rms_sensors_check.check_column_sum("DCEM Sensor","data.csv","output.csv",31,31)

#check for GCU fault
print("checking for GCU sensor Fault")
rms_sensors_check.check_column_sum("GCU Sensor","data.csv","output.csv",32,32)

#check for Solar em fault
print("checking for Solar sensor Fault")
rms_sensors_check.check_column_sum("Solar Sensor","data.csv","output.csv",33,33)

#check for System Controller  fault
print("checking for System Controller(Rectifier Controller Comm Fault) sensor Fault")
rms_sensors_check.check_column_sum("System Controller Sensor","data.csv","output.csv",13,13)

#check for Fuel Sensor  fault
print("checking for Fuel sensor Fault")
rms_sensors_check.check_column_sum("Fuel Sensor","data.csv","output.csv",34,34)

#check for Li_battery fault
print("checking for Li_Battery  sensor Fault")
rms_sensors_check.check_column_sum("Li_Battery Sensor","data.csv","output.csv",14,29)

# #get the column values
col_operations.subtract_first_last('Battery run hours','data.csv',11,'output1.csv')
col_operations.subtract_first_last('DG Energy','data.csv',4,'output1.csv')
col_operations.subtract_first_last('DG Run Hours','data.csv',6,'output1.csv')
col_operations.subtract_first_last('Tenant Energy','data.csv',9,'output1.csv')
col_operations.subtract_first_last('CP Meter','data.csv',5,'output1.csv')






import merge
merge.root.mainloop()
import destroy
destroy.delete_csv_excel_files()




