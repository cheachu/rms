import tkinter as tk
from tkinter import filedialog
import shutil

def browse_file_1():
    filename = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if filename:
        entry_file1.delete(0, tk.END)
        entry_file1.insert(0, filename)

def browse_file_2():
    filename = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if filename:
        entry_file2.delete(0, tk.END)
        entry_file2.insert(0, filename)

def copy_files():
    file1_path = entry_file1.get()
    file2_path = entry_file2.get()
    
    if file1_path and file2_path:
        shutil.copy(file1_path, "data.csv")
        shutil.copy(file2_path, "data1.xlsx")
        print("Files copied to project folder.")
        root.destroy()  # Close the dialog box
    else:
        print("Please select both files.")

# Create main application window
root = tk.Tk()
#img = tk.PhotoImage(file="logo.png")
#root.iconphoto(False, img)
root.title("CSV File Copier")


# File 1
label_file1 = tk.Label(root, text="Log Analyzer File :")
label_file1.grid(row=0, column=0, sticky=tk.W)

entry_file1 = tk.Entry(root, width=50)
entry_file1.grid(row=0, column=1)

browse_button1 = tk.Button(root, text="Browse", command=browse_file_1)
browse_button1.grid(row=0, column=2)

# File 2
label_file2 = tk.Label(root, text="Run Hours and Consumption Report:")
label_file2.grid(row=1, column=0, sticky=tk.W)

entry_file2 = tk.Entry(root, width=50)
entry_file2.grid(row=1, column=1)

browse_button2 = tk.Button(root, text="Browse", command=browse_file_2)
browse_button2.grid(row=1, column=2)

# Copy button
copy_button = tk.Button(root, text="Copy Files to Project Folder", command=copy_files)
copy_button.grid(row=2, column=1)

# Run the main event loop
root.mainloop()
