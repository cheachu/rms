import os

def delete_csv_excel_files():
    try:
        # Get the directory of the program
        program_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Get a list of all files in the directory
        files = os.listdir(program_dir)
        
        # Loop through each file
        for file in files:
            # Check if the file is a CSV or Excel file
            if file.endswith(".csv") or file.endswith(".xlsx"):
                # Construct the file path
                file_path = os.path.join(program_dir, file)
                # Delete the file
                os.remove(file_path)
                print(f"Deleted: {file_path}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

# Call the function to delete CSV and Excel files
delete_csv_excel_files()
