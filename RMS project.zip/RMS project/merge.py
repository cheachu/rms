import pandas as pd
import tkinter as tk
from tkinter import filedialog

def merge_files_and_save():
    # Read the CSV files and Excel sheet
    csv1 = pd.read_csv('output.csv')
    csv2 = pd.read_csv('output1.csv')
    excel = pd.read_excel('data1.xlsx')

    # Merge the dataframes
    merged_df = pd.concat([csv1, csv2, excel], ignore_index=True)
    
    # Get the output file path from the user
    output_file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
    
    if output_file_path:
        # Write the merged dataframe to a CSV file
        merged_df.to_csv(output_file_path, index=False)
        print("Merged file saved as:", output_file_path)
        # Update GUI label to show completion
        status_label.config(text="Merged file saved as:\n" + output_file_path)

# Create the main window
root = tk.Tk()
root.title("Merge Files")

# Create a button to trigger the merging process
merge_button = tk.Button(root, text="Merge Files and Save", command=merge_files_and_save)
merge_button.pack(pady=10)

# Create a label to show the status
status_label = tk.Label(root, text="")
status_label.pack(pady=5)

# Run the Tkinter event loop
root.mainloop()
